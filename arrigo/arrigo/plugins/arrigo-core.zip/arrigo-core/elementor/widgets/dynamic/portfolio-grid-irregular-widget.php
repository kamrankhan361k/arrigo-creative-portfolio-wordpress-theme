<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Arrigo_Elementor_Portfolio_Grid_Irregular_Widget extends \Elementor\Widget_Base {
	private static $_instance = null;

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	public function get_name() {
		return 'arrigo-widget-portfolio-grid-irregular';
	}

	public function get_title() {
		return _x( 'Portfolio Grid Irregular', 'Elementor Widget Title', 'arrigo' );
	}

	public function get_icon() {
		return 'eicon-sitemap';
	}

	public function get_categories() {
		return array( 'arrigo-dynamic' );
	}

	private $_settings;
	private static $_posts;
	private static $_post_type;

	private static function _get_posts() {

		$args = apply_filters(
			'arr/elementor/arrigo_elementor_portfolio_grid_irregular_widget/query_args',
			array(
				'post_type'      => 'arr_portfolio',
				'posts_per_page' => -1,
			)
		);

		$posts   = array();
		$counter = 0;

		$loop = new WP_Query( $args );

		if ( $loop->have_posts() ) {

			while ( $loop->have_posts() ) {

				$loop->the_post();

				$post_id         = get_the_ID();
				$post_title      = get_the_title();
				$post_link       = get_the_permalink();
				$post_image      = get_post_thumbnail_id();
				$post_categories = get_the_terms( $post_id, 'arr_portfolio_category' );

				$posts[ $counter ]['id']         = $post_id;
				$posts[ $counter ]['title']      = $post_title;
				$posts[ $counter ]['permalink']  = $post_link;
				$posts[ $counter ]['image_id']   = $post_image;
				$posts[ $counter ]['categories'] = $post_categories;

				$counter++;

			}

			wp_reset_postdata();

		}

		self::$_posts     = $posts;
		self::$_post_type = array_key_exists( 'post_type', $args ) ? $args['post_type'] : '';
	}

	protected function register_controls() {

		if ( is_null( self::$_posts ) ) {
			self::_get_posts();
		}

		$posts     = self::$_posts;
		$post_type = self::$_post_type;

		/**
		 * Section Content
		 */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => _x( 'Content', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		foreach ( $posts as $index => $item ) {

			/**
			 * Heading Item
			 */
			$id = 'heading_item' . $item['id'];
			$this->add_control(
				$id,
				array(
					'raw'        => sprintf(
						'<h3 class="elementor-control-title"><strong>%1$s</strong>&nbsp;&nbsp;<a href="%2$s" target="_blank"><i class="eicon-edit"></i></a></h3>',
						$item['title'],
						admin_url( 'post.php?post=' . $item['id'] . '&action=edit' ),
						esc_html__( 'Edit', 'arrigo' )
					),
					'type'       => \Elementor\Controls_Manager::RAW_HTML,
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => _x( 'Enabled', 'Elementor Widget', 'arrigo' ),
					'type'       => \Elementor\Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Image Orientation
			 */
			$id = 'orientation' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => _x( 'Image Orientation', 'Elementor Widget', 'arrigo' ),
					'type'       => \Elementor\Controls_Manager::SELECT,
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
					'options'    => array(
						'figure-portfolio_horizontal' => _x( 'Landscape', 'Elementor Widget', 'arrigo' ),
						'figure-portfolio_vertical'   => _x( 'Portrait', 'Elementor Widget', 'arrigo' ),
					),
					'default'    => 'figure-portfolio_horizontal',
				)
			);

			/**
			 * Content Alignment
			 */
			$id = 'content' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => _x( 'Image Position', 'Elementor Widget', 'arrigo' ),
					'type'       => \Elementor\Controls_Manager::SELECT,
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
					'separator'  => 'after',
					'options'    => array(
						'figure-portfolio_left'  => _x( 'Image Left', 'Elementor Widget', 'arrigo' ),
						'figure-portfolio_right' => _x( 'Image Right', 'Elementor Widget', 'arrigo' ),
					),
					'default'    => 'figure-portfolio_left',
				)
			);

		}

		/**
		 * Not Editable Widget Info
		 */
		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s<br><br>%2$s <a href="%3$s" target="_blank">%4$s</a>',
					_x( 'This widget displays content dynamically from the existing posts. It\'s not editable directly through Elementor Page Builder.', 'Elementor Widget', 'arrigo' ),
					_x( 'You can edit or re-order your posts', 'Elementor Widget', 'arrigo' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					_x( 'in WordPress admin panel', 'Elementor Widget', 'arrigo' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Settings
		 */
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => _x( 'Settings', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
			)
		);

		/**
		 * Number of Posts
		 */
		$this->add_control(
			'posts_amount',
			array(
				'label'   => _x( 'Number of Portfolio Items to Display (0 for all)', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'number' => array(
						'min'  => 0,
						'max'  => 32,
						'step' => 1,
					),
				),
				'default' => array(
					'unit' => 'number',
					'size' => 4,
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Section Animation
		 */
		$this->start_controls_section(
			'animation_section',
			array(
				'label' => _x( 'Animation', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * OS Animation
		 */
		$this->add_control(
			'enable_animation',
			array(
				'label'        => _x( 'Enable on-scroll animation', 'Elementor Widget', 'arrigo' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'data-os-animation="data-os-animation"',
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings        = $this->get_settings_for_display();
		$this->_settings = $settings;

		if ( is_null( self::$_posts ) ) {
			self::_get_posts();
		}

		$posts = self::$_posts;

		// limit posts amount
		if ( is_array( $settings['posts_amount'] ) && $settings['posts_amount']['size'] > 0 ) {
			array_splice( $posts, $settings['posts_amount']['size'] );
		}

		// filter only "enabled" posts
		$posts = array_filter(
			$posts,
			function( $item ) {
				return ( array_key_exists( 'enabled' . $item['id'], $this->_settings ) ) && ( $this->_settings[ 'enabled' . $item['id'] ] );
			}
		);

		?>

		<?php if ( ! empty( $posts ) ) : ?>
			<div class="container">
				<?php foreach ( $posts as $item ) : ?>
					<?php
						$post_id           = $item['id'];
						$orientation_class = $settings[ 'orientation' . $post_id ];
						$content_class     = $settings[ 'content' . $post_id ];
						$col_class         = $orientation_class == 'figure-portfolio_horizontal' ? 'col-lg-10' : 'col-lg-5';
						$row_class         = $content_class == 'figure-portfolio_left' ? 'justify-content-start' : 'justify-content-end';

						$this->add_render_attribute(
							$post_id . 'row',
							'class',
							array(
								'row',
								'figure-portfolio',
								$row_class,
								$orientation_class,
								$content_class,
							)
						);

						$this->add_render_attribute(
							$post_id . 'col',
							array(
								'class' => array(
									'figure-portfolio__link',
									'col',
									$col_class,
								),
								'href'  => $item['permalink'],
							)
						);

					if ( $settings['enable_animation'] ) {
						$this->add_render_attribute( $post_id . 'row', 'data-os-animation' );
					}

					?>
					<div class="section-portfolio__wrapper-item">
						<div <?php echo $this->get_render_attribute_string( $post_id . 'row' ); ?>>
							<a <?php echo $this->get_render_attribute_string( $post_id . 'col' ); ?>>
								<?php if ( $item['image_id'] ) : ?>
									<div class="figure-portfolio__wrapper-img overflow">
										<?php if ( $settings['enable_animation'] ) : ?>
											<div class="overflow__curtain bg-accent"></div>
											<div class="overflow__content">
												<?php
													arr_the_lazy_image(
														array(
															'id' => $item['image_id'],
														)
													);
												?>
											</div>
										<?php else : ?>
											<?php
												arr_the_lazy_image(
													array(
														'id' => $item['image_id'],
													)
												);
											?>
										<?php endif; ?>
									</div>
								<?php endif; ?>
								<?php if ( ! empty( $item['categories'] ) ) : ?>
								<div class="figure-portfolio__info">
									<?php foreach ( $item['categories'] as $category ) : ?>
										<span><?php echo esc_html( $category->name ); ?></span>
									<?php endforeach; ?>
								</div>
								<?php endif; ?>
								<?php if ( ! empty( $item['title'] ) ) : ?>
									<header class="figure-portfolio__header">
										<div class="figure-portfolio__headline"></div>
										<h2><?php echo $item['title']; ?></h2>
									</header>
								<?php endif; ?>
							</a>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php
	}
}
