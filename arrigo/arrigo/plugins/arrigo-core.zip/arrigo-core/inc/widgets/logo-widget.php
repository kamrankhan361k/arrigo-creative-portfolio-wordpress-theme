<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Widget Social
 */
class Arrigo_Widget_Logo extends WP_Widget {
	function __construct() {
		parent::__construct(
			'arrigo_logo',
			__( 'Arrigo: Logo', 'arrigo' ),
			array( 'description' => __( 'Displays site logotype', 'arrigo' ) )
		);
	}

	/**
	 * Display widget on frontend
	 *
	 * @param array $args     widget arguments.
	 * @param array $instance saved data from settings
	 */
	function widget( $args, $instance ) {
		echo $args['before_widget'];
		get_template_part( 'template-parts/logo/logo' );
		echo $args['after_widget'];
	}
}
