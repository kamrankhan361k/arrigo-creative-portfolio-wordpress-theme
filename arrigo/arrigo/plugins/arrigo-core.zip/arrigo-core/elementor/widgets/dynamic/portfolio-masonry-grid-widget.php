<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Arrigo_Elementor_Portfolio_Masonry_Grid_Widget extends \Elementor\Widget_Base {
	private static $_instance = null;

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	public function get_name() {
		return 'arrigo-widget-portfolio-masonry-grid';
	}

	public function get_title() {
		return _x( 'Portfolio Masonry Grid & Gallery', 'Elementor Widget Title', 'arrigo' );
	}

	public function get_icon() {
		return 'eicon-sitemap';
	}

	public function get_categories() {
		return array( 'arrigo-dynamic' );
	}

	private $_settings;
	private static $_posts;
	private static $_post_type;
	private static $_taxonomies;

	private static function _get_posts() {

		$args = apply_filters(
			'arr/elementor/arrigo_elementor_portfolio_masonry_grid_widget/query_args',
			array(
				'post_type'      => 'arr_portfolio',
				'posts_per_page' => -1,
			)
		);

		$posts      = array();
		$taxonomies = array();
		$counter    = 0;

		$loop = new WP_Query( $args );

		if ( $loop->have_posts() ) {

			while ( $loop->have_posts() ) {

				$loop->the_post();

				$post_id                               = get_the_ID();
				$post_title                            = get_the_title();
				$post_link                             = get_the_permalink();
				$post_image                            = get_post_thumbnail_id();
				$post_image_url                        = get_the_post_thumbnail_url();
				$post_categories                       = get_the_terms( $post_id, 'arr_portfolio_category' );
				$posts[ $counter ]['id']               = $post_id;
				$posts[ $counter ]['title']            = $post_title;
				$posts[ $counter ]['permalink']        = $post_link;
				$posts[ $counter ]['image_id']         = $post_image;
				$posts[ $counter ]['image_url']        = $post_image_url;
				$posts[ $counter ]['categories']       = $post_categories;
				$posts[ $counter ]['categories_names'] = array();

				if ( is_array( $post_categories ) && ! empty( $post_categories ) ) {
					foreach ( $post_categories as $item ) {

						$arr = array(
							'slug' => $item->slug,
							'name' => $item->name,
						);

						array_push( $posts[ $counter ]['categories_names'], $item->name );

						// don't add the same item multiple times
						if ( ! in_array( $arr, $taxonomies ) ) {
							array_push( $taxonomies, $arr );
						}
					}
				}

				$counter++;

			}

			wp_reset_postdata();

		}

		self::$_taxonomies = $taxonomies;
		self::$_posts      = $posts;
		self::$_post_type  = array_key_exists( 'post_type', $args ) ? $args['post_type'] : '';
	}

	protected function register_controls() {

		if ( is_null( self::$_posts ) ) {
			self::_get_posts();
		}

		$posts     = self::$_posts;
		$post_type = self::$_post_type;

		/**
		 * Section Content
		 */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => _x( 'Images', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		foreach ( $posts as $index => $item ) {

			/**
			 * Heading Item
			 */
			$id = 'heading_item' . $item['id'];
			$this->add_control(
				$id,
				array(
					'raw'        => sprintf(
						'<h3 class="elementor-control-title"><strong>%1$s</strong>&nbsp;&nbsp;<a href="%2$s" target="_blank"><i class="eicon-edit"></i></a></h3>',
						$item['title'],
						admin_url( 'post.php?post=' . $item['id'] . '&action=edit' ),
						esc_html__( 'Edit', 'arrigo' )
					),
					'type'       => \Elementor\Controls_Manager::RAW_HTML,
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => _x( 'Enabled', 'Elementor Widget', 'arrigo' ),
					'type'       => \Elementor\Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
					'separator'  => 'after',
				)
			);

		}

		/**
		 * Not Editable Widget Info
		 */
		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s<br><br>%2$s <a href="%3$s" target="_blank">%4$s</a>',
					_x( 'This widget displays content dynamically from the existing posts. It\'s not editable directly through Elementor Page Builder.', 'Elementor Widget', 'arrigo' ),
					_x( 'You can edit or re-order your posts', 'Elementor Widget', 'arrigo' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					_x( 'in WordPress admin panel', 'Elementor Widget', 'arrigo' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Settings
		 */
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => _x( 'Settings', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
			)
		);

		/**
		 * Number of Posts
		 */
		$this->add_control(
			'posts_amount',
			array(
				'label'   => _x( 'Number of Portfolio Items to Display (0 for all)', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'number' => array(
						'min'  => 0,
						'max'  => 32,
						'step' => 1,
					),
				),
				'default' => array(
					'unit' => 'number',
					'size' => 0,
				),
			)
		);

		/**
		 * Isotope Filter
		 */
		$this->add_control(
			'enable_filter',
			array(
				'label' => _x( 'Enable Grid Filter', 'Elementor Widget', 'arrigo' ),
				'type'  => \Elementor\Controls_Manager::SWITCHER,
			)
		);

		/**
		 * Enable Lightbox
		 */
		$this->add_control(
			'lightbox',
			array(
				'label'   => _x( 'Enable Lightbox', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		/**
		 * Show Title
		 */
		$this->add_control(
			'show_title',
			array(
				'label'   => _x( 'Show Item Title', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		/**
		 * Show Categories
		 */
		$this->add_control(
			'show_categories',
			array(
				'label'     => _x( 'Show Item Categories', 'Elementor Widget', 'arrigo' ),
				'type'      => \Elementor\Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => array(
					'show_title' => 'yes',
				),
			)
		);

		/**
		 * Show Headline
		 */
		$this->add_control(
			'show_headline',
			array(
				'label'     => _x( 'Show Title Headline', 'Elementor Widget', 'arrigo' ),
				'type'      => \Elementor\Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => array(
					'show_title' => 'yes',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Section Layout
		 */
		$this->start_controls_section(
			'layout_section',
			array(
				'label' => _x( 'Layout', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_LAYOUT,
			)
		);

		/**
		 * Columns
		 */
		$this->add_responsive_control(
			'columns',
			array(
				'label'           => _x( 'Columns', 'Elementor Widget', 'arrigo' ),
				'type'            => \Elementor\Controls_Manager::SELECT,
				'options'         => array(
					3  => _x( 'Four Columns', 'Elementor Widget', 'arrigo' ),
					4  => _x( 'Three Columns', 'Elementor Widget', 'arrigo' ),
					6  => _x( 'Two Columns', 'Elementor Widget', 'arrigo' ),
					12 => _x( 'Single Column', 'Elementor Widget', 'arrigo' ),
				),
				'render_type'     => 'template',
				'desktop_default' => 4,
				'tablet_default'  => 6,
				'mobile_default'  => 12,
			)
		);

		/**
		 * Space Between
		 */
		$this->add_responsive_control(
			'space_between',
			array(
				'label'           => _x( 'Space Between', 'Elementor Widget', 'arrigo' ),
				'type'            => \Elementor\Controls_Manager::SLIDER,
				'range'           => array(
					'px' => array(
						'min'  => 0,
						'max'  => 120,
						'step' => 1,
					),
				),
				'devices'         => array( 'desktop', 'tablet', 'mobile' ),
				'desktop_default' => array(
					'size' => 80,
				),
				'tablet_default'  => array(
					'size' => 30,
				),
				'mobile_default'  => array(
					'size' => 15,
				),
				'selectors'       => array(
					'{{WRAPPER}} .grid'       => 'margin: calc(-{{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid__item' => 'padding: calc({{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .filter'     => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
				'render_type'     => 'template',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Animation
		 */
		$this->start_controls_section(
			'animation_section',
			array(
				'label' => _x( 'Animation', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * OS Animation
		 */
		$this->add_control(
			'enable_animation',
			array(
				'label'        => _x( 'Enable on-scroll animation', 'Elementor Widget', 'arrigo' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'data-os-animation="data-os-animation"',
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings        = $this->get_settings_for_display();
		$this->_settings = $settings;

		if ( is_null( self::$_posts ) ) {
			self::_get_posts();
		}

		$posts = self::$_posts;

		// limit posts amount
		if ( is_array( $settings['posts_amount'] ) && $settings['posts_amount']['size'] > 0 ) {
			array_splice( $posts, $settings['posts_amount']['size'] );
		}

		$taxonomies        = self::$_taxonomies;
		$active_taxonomies = array();
		$col_desktop       = 'grid__item_desktop-' . $settings['columns'];
		$col_tablet        = 'grid__item_tablet-' . $settings['columns_tablet'];
		$col_mobile        = 'grid__item_mobile-' . $settings['columns_mobile'];
		$lightbox          = $settings['lightbox'];

		$this->add_render_attribute(
			'section',
			array(
				'class'                    => array( 'grid', 'js-grid' ),
				'data-grid-columns'        => 12 / $settings['columns'],
				'data-grid-columns-tablet' => 12 / $settings['columns_tablet'],
				'data-grid-columns-mobile' => 12 / $settings['columns_mobile'],
			)
		);

		$this->add_render_attribute(
			'sizerAtts',
			array(
				'class' => array( 'grid__sizer', 'js-grid__sizer', $col_desktop, $col_tablet, $col_mobile ),
			)
		);

		if ( $settings['enable_animation'] ) {
			$this->add_render_attribute( 'section', 'data-os-animation' );
		}

		?>

		<?php if ( ! empty( $taxonomies && $settings['enable_filter'] ) ) : ?>
			<?php foreach ( $posts as $index => $item ) : ?>
				<?php $is_enabled = ( array_key_exists( 'enabled' . $item['id'], $settings ) ) && ( $settings[ 'enabled' . $item['id'] ] ); ?>
				<?php if ( $is_enabled ) : ?>
					<?php
					if ( is_array( $item['categories'] ) ) {
						foreach ( $item['categories'] as $taxonomy ) {

							$arr = array(
								'slug' => $taxonomy->slug,
								'name' => $taxonomy->name,
							);

							// don't add the same item multiple times
							if ( ! in_array( $arr, $active_taxonomies ) ) {
								array_push( $active_taxonomies, $arr );
							}
						}
					}
					?>
				<?php endif; ?>
			<?php endforeach; ?>
				<?php if ( ! empty( $active_taxonomies ) ) : ?>
				<div class="filter">
					<ul class="filter__list js-filter">
						<li class="filter__item filter__item_active js-filter__item" data-filter="*"><?php esc_html_e( 'All', 'arrigo' ); ?></li>
						<?php foreach ( $active_taxonomies as $item ) : ?>
							<li class="filter__item js-filter__item" data-filter=".category-<?php echo $item['slug']; ?>"><?php echo $item['name']; ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
		<?php endif; ?>

		<?php if ( ! empty( $posts ) ) : ?>
			<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
				<div <?php echo $this->get_render_attribute_string( 'sizerAtts' ); ?>></div>
				<?php foreach ( $posts as $index => $item ) : ?>
					<?php $is_enabled = ( array_key_exists( 'enabled' . $item['id'], $settings ) ) && ( $settings[ 'enabled' . $item['id'] ] ); ?>
					<?php if ( $is_enabled ) : ?>
						<?php

							$categories = array();
						if ( is_array( $item['categories'] ) && ! empty( $item['categories'] ) ) {
							foreach ( $item['categories'] as $taxonomy ) {

								$this->add_render_attribute(
									'itemAtts' . $index,
									array(
										'class' => 'category-' . esc_attr( $taxonomy->slug ),
									)
								);
								$categories[] .= $taxonomy->name;

							}
						}

							$this->add_render_attribute(
								'itemAtts' . $index,
								array(
									'class' => array( 'grid__item', 'js-grid__item', $col_desktop, $col_tablet, $col_mobile ),
								)
							);

						?>
						<?php if ( $item['image_url'] ) : ?>
							<div <?php echo $this->get_render_attribute_string( 'itemAtts' . $index ); ?>>
								<?php
								$this->add_render_attribute(
									'linkAtts',
									array(
										'class' => 'grid__item-link',
										'href'  => $item['permalink'],
									),
									true,
									true
								);

								if ( $lightbox ) {
									$this->add_render_attribute(
										'linkAtts',
										array(
											'href' => $item['image_url'],
											'data-elementor-open-lightbox' => 'true',
											'data-elementor-lightbox-slideshow' => $this->get_id(),
										),
										true,
										true
									);
								}
								?>
								<a <?php echo $this->get_render_attribute_string( 'linkAtts' ); ?>>
									<div class="grid__item-wrapper-img">
										<?php if ( $lightbox ) : ?>
											<div class="grid__item-icon">
												<div class="grid__item-icon-symbol lnr lnr-magnifier"></div>
												<svg viewBox="0 0 152 152" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
													<g fill="none" fill-rule="evenodd">
														<g transform="translate(-134.000000, -98.000000)">
															<path class="circle" d="M135,174a75,75 0 1,0 150,0a75,75 0 1,0 -150,0"></path>
														</g>
													</g>
												</svg>
											</div>
											<div class="overlay overlay_dark grid__item-overlay"></div>
										<?php endif; ?>
										<?php
											arr_the_lazy_image(
												array(
													'id'   => $item['image_id'],
													'type' => 'image',
												)
											);
										?>
									</div>
									<?php if ( $settings['show_title'] ) : ?>
										<div class="grid__item-header">
											<?php if ( $settings['show_categories'] && ! empty( $item['categories'] ) ) : ?>
												<ul class="post-meta">
													<?php foreach ( $item['categories'] as $category ) : ?>
														<li><?php echo esc_html( $category->name ); ?></li>
													<?php endforeach; ?>
												</ul>
											<?php endif; ?>
											<h3><?php echo $item['title']; ?></h3>
											<?php if ( $settings['show_headline'] ) : ?>
												<div class="grid__item-headline"></div>
											<?php endif; ?>
										</div>
									<?php endif; ?>
								</a>
							</div>
						<?php endif; ?>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<?php
	}

}
