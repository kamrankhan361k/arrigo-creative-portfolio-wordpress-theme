<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Arrigo_Elementor_Portfolio_Slider_Fullscreen_2_Widget extends \Elementor\Widget_Base {
	private static $_instance = null;

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	public function get_name() {
		return 'arrigo-widget-portfolio-slider-fullscreen-2';
	}

	public function get_title() {
		return _x( 'Portfolio Slider Fullscreen 2', 'Elementor Widget Title', 'arrigo' );
	}

	public function get_icon() {
		return 'eicon-sitemap';
	}

	public function get_categories() {
		return array( 'arrigo-dynamic' );
	}

	private $_settings;
	private static $_posts;
	private static $_post_type;

	private static function _get_posts() {

		$args = apply_filters(
			'arr/elementor/arrigo_elementor_portfolio_slider_fullscreen_2_widget/query_args',
			array(
				'post_type'      => 'arr_portfolio',
				'posts_per_page' => -1,
			)
		);

		$posts      = array();
		$taxonomies = array();
		$counter    = 0;

		$loop = new WP_Query( $args );

		if ( $loop->have_posts() ) {

			while ( $loop->have_posts() ) {

				$loop->the_post();

				$post_id         = get_the_ID();
				$post_title      = get_the_title();
				$post_link       = get_the_permalink();
				$post_image      = get_post_thumbnail_id();
				$post_categories = get_the_terms( $post_id, 'arr_portfolio_category' );

				if ( is_array( $post_categories ) && ! empty( $post_categories ) ) {
					foreach ( $post_categories as $item ) {

						$arr = array(
							'slug' => $item->slug,
							'name' => $item->name,
						);

						// don't add the same item multiple times
						if ( ! in_array( $arr, $taxonomies ) ) {
							array_push( $taxonomies, $arr );
						}
					}
				}

				$posts[ $counter ]['id']          = $post_id;
				$posts[ $counter ]['title']       = $post_title;
				$posts[ $counter ]['permalink']   = $post_link;
				$posts[ $counter ]['image_id']    = $post_image;
				$posts[ $counter ]['categories']  = $post_categories;
				$posts[ $counter ]['description'] = get_post_meta( $post_id, 'portfolio_item_short_description', true );

				$counter++;

			}

			wp_reset_postdata();

		}

		self::$_posts     = $posts;
		self::$_post_type = array_key_exists( 'post_type', $args ) ? $args['post_type'] : '';
	}

	protected function register_controls() {

		if ( is_null( self::$_posts ) ) {
			self::_get_posts();
		}

		$posts     = self::$_posts;
		$post_type = self::$_post_type;

		/**
		 * Section Content
		 */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => _x( 'Content', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		foreach ( $posts as $index => $item ) {

			/**
			 * Heading Item
			 */
			$id = 'heading_item' . $item['id'];
			$this->add_control(
				$id,
				array(
					'raw'        => sprintf(
						'<h3 class="elementor-control-title"><strong>%1$s</strong>&nbsp;&nbsp;<a href="%2$s" target="_blank"><i class="eicon-edit"></i></a></h3>',
						$item['title'],
						admin_url( 'post.php?post=' . $item['id'] . '&action=edit' ),
						esc_html__( 'Edit', 'arrigo' )
					),
					'type'       => \Elementor\Controls_Manager::RAW_HTML,
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => _x( 'Enabled', 'Elementor Widget', 'arrigo' ),
					'type'       => \Elementor\Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
					'separator'  => 'after',
				)
			);

		}

		/**
		 * Not Editable Widget Info
		 */
		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s<br><br>%2$s <a href="%3$s" target="_blank">%4$s</a>',
					_x( 'This widget displays content dynamically from the existing posts. It\'s not editable directly through Elementor Page Builder.', 'Elementor Widget', 'arrigo' ),
					_x( 'You can edit or re-order your posts', 'Elementor Widget', 'arrigo' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					_x( 'in WordPress admin panel', 'Elementor Widget', 'arrigo' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Social
		 */
		$this->start_controls_section(
			'social_section',
			array(
				'label' => _x( 'Social', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		/**
		 * Social Heading
		 */
		$this->add_control(
			'social_heading',
			array(
				'label' => _x( 'Social Media', 'Elementor Widget', 'arrigo' ),
				'type'  => \Elementor\Controls_Manager::HEADING,
			)
		);

		$repeater = new \Elementor\Repeater();

		/**
		 * Social Link
		 */
		$repeater->add_control(
			'social_link',
			array(
				'label'         => _x( 'Link', 'Elementor Widget', 'arrigo' ),
				'type'          => \Elementor\Controls_Manager::URL,
				'placeholder'   => _x( 'https://...', 'Elementor Widget', 'arrigo' ),
				'show_external' => true,
				'default'       => array(
					'is_external' => true,
					'nofollow'    => true,
				),
			)
		);

		/**
		 * Social Icon
		 */
		$repeater->add_control(
			'social_icon',
			array(
				'label' => _x( 'Icon', 'Elementor Widget', 'arrigo' ),
				'type'  => \Elementor\Controls_Manager::ICON,
			)
		);

		/**
		 * Social Repeater Control
		 */
		$this->add_control(
			'social',
			array(
				'type'          => \Elementor\Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ social_icon.replace("fa fa-", "") }}}',
				'prevent_empty' => false,
			)
		);

		$this->end_controls_section();

		/**
		 * Section Slider
		 */
		$this->start_controls_section(
			'slider_section',
			array(
				'label' => _x( 'Slider', 'Elementor Widget', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
			)
		);

		/**
		 * Slides Per Screen
		 */
		$this->add_responsive_control(
			'slides_per_view',
			array(
				'label'           => _x( 'Slides Per Screen', 'Elementor Widget', 'arrigo' ),
				'type'            => \Elementor\Controls_Manager::SLIDER,
				'range'           => array(
					'number' => array(
						'min'  => 1,
						'max'  => 4,
						'step' => 1,
					),
				),
				'devices'         => array( 'desktop', 'tablet', 'mobile' ),
				'desktop_default' => array(
					'size' => 4,
					'unit' => 'number',
				),
				'tablet_default'  => array(
					'size' => 2,
					'unit' => 'number',
				),
				'mobile_default'  => array(
					'size' => 1,
					'unit' => 'number',
				),
			)
		);

		/**
		 * Navigation
		 */
		$this->add_control(
			'enable_navigation',
			array(
				'label'   => _x( 'Enable Navigation Arrows', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		/**
		 * Progress Bar
		 */
		$this->add_control(
			'enable_progress',
			array(
				'label'   => _x( 'Enable Progress Bar', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		/**
		 * Autoplay
		 */
		$this->add_control(
			'enable_autoplay',
			array(
				'label'   => _x( 'Autoplay', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		/**
		 * Autoplay Delay
		 */
		$this->add_control(
			'autoplay_delay',
			array(
				'label'     => _x( 'Autoplay Delay (ms)', 'Elementor Widget', 'arrigo' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'ms' => array(
						'min'  => 1000,
						'max'  => 60000,
						'step' => 100,
					),
				),
				'default'   => array(
					'unit' => 'ms',
					'size' => 6000,
				),
				'condition' => array(
					'enable_autoplay' => 'yes',
				),
			)
		);

		/**
		 * Speed
		 */
		$this->add_control(
			'speed',
			array(
				'label'   => _x( 'Speed', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'ms' => array(
						'min'  => 100,
						'max'  => 10000,
						'step' => 100,
					),
				),
				'default' => array(
					'unit' => 'ms',
					'size' => 800,
				),
			)
		);

		/**
		 * Direction
		 */
		$this->add_control(
			'direction',
			array(
				'label'   => _x( 'Direction', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'default' => 'ltr',
				'options' => array(
					'ltr' => array(
						'title' => _x( 'Left to Right', 'Elementor Widget', 'arrigo' ),
						'icon'  => 'eicon-chevron-double-right',
					),
					'rtl' => array(
						'title' => _x( 'Right to Left', 'Elementor Widget', 'arrigo' ),
						'icon'  => 'eicon-chevron-double-left',
					),
				),
				'toggle'  => false,
			)
		);

		$this->end_controls_section();

		/**
		 * Section Settings
		 */
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => _x( 'Settings', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
			)
		);

		/**
		 * Number of Posts
		 */
		$this->add_control(
			'posts_amount',
			array(
				'label'   => _x( 'Number of Portfolio Items to Display (0 for all)', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'number' => array(
						'min'  => 0,
						'max'  => 16,
						'step' => 1,
					),
				),
				'default' => array(
					'unit' => 'number',
					'size' => 4,
				),
			)
		);

		/**
		 * Show Categories
		 */
		$this->add_control(
			'show_categories',
			array(
				'label'   => _x( 'Show Categories', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => '',
			)
		);

		/**
		 * Show Description
		 */
		$this->add_control(
			'show_description',
			array(
				'label'   => _x( 'Show Short Description', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => '',
			)
		);

		/**
		 * Show Description
		 */
		$this->add_control(
			'show_headline',
			array(
				'label'   => _x( 'Show Headline', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Style
		 */
		$this->start_controls_section(
			'style_section',
			array(
				'label' => _x( 'Style', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * Color Theme
		 */
		$this->add_control(
			'color_theme',
			array(
				'label'   => _x( 'Color Theme', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => array(
					'slider-fullscreen4_dark'  => array(
						'title' => _x( 'Dark', 'Elementor Widget', 'arrigo' ),
						'icon'  => 'eicon-circle',
					),
					'slider-fullscreen4_light' => array(
						'title' => _x( 'Light', 'Elementor Widget', 'arrigo' ),
						'icon'  => 'eicon-circle-o',
					),
				),
				'default' => 'slider-fullscreen4_light',
				'toggle'  => false,
			)
		);

		$this->end_controls_section();

		/**
		 * Section Animation
		 */
		$this->start_controls_section(
			'animation_section',
			array(
				'label' => _x( 'Animation', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * OS Animation
		 */
		$this->add_control(
			'enable_animation',
			array(
				'label'        => _x( 'Enable on-scroll animation', 'Elementor Widget', 'arrigo' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'data-os-animation="data-os-animation"',
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings        = $this->get_settings_for_display();
		$this->_settings = $settings;

		if ( is_null( self::$_posts ) ) {
			self::_get_posts();
		}

		$posts = self::$_posts;

		// limit posts amount
		if ( is_array( $settings['posts_amount'] ) && $settings['posts_amount']['size'] > 0 ) {
			array_splice( $posts, $settings['posts_amount']['size'] );
		}

		// filter only "enabled" posts
		$posts = array_filter(
			$posts,
			function( $item ) {
				return ( array_key_exists( 'enabled' . $item['id'], $this->_settings ) ) && ( $this->_settings[ 'enabled' . $item['id'] ] );
			}
		);

		$this->add_render_attribute( 'section', 'class', array( 'section', 'section-fullscreen', 'section-fullscreen_4' ) );

		$this->add_render_attribute(
			'swiper',
			array(
				'class'                       => array( 'swiper', 'swiper-container', 'slider-fullscreen4', 'js-slider-fullscreen4', $settings['color_theme'] ),
				'data-speed'                  => is_array( $settings['speed'] ) ? $settings['speed']['size'] : 0,
				'dir'                         => $settings['direction'],
				'data-slides-per-view'        => is_array( $settings['slides_per_view'] ) ? $settings['slides_per_view']['size'] : 0,
				'data-slides-per-view-tablet' => is_array( $settings['slides_per_view'] ) ? $settings['slides_per_view_tablet']['size'] : 0,
				'data-slides-per-view-mobile' => is_array( $settings['slides_per_view'] ) ? $settings['slides_per_view_mobile']['size'] : 0,
			)
		);

		if ( $settings['enable_autoplay'] ) {
			$this->add_render_attribute(
				'swiper',
				array(
					'data-autoplay-enabled' => 'true',
					'data-autoplay-delay'   => is_array( $settings['autoplay_delay'] ) ? $settings['autoplay_delay']['size'] : 0,
				)
			);
		}

		if ( $settings['enable_animation'] ) {
			$this->add_render_attribute( 'section', 'data-os-animation' );
		}

		?>

		<?php if ( ! empty( $posts ) ) : ?>
			<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
				<div <?php echo $this->get_render_attribute_string( 'swiper' ); ?>>
					<div class="swiper-wrapper">
						<?php foreach ( $posts as $item ) : ?>
							<div class="swiper-slide">
								<div class="slider-fullscreen4__slide-wrapper-bg">
									<?php if ( ! empty( $item['title'] ) ) : ?>
										<header class="slider-fullscreen4__slide-header">
											<?php if ( $settings['show_headline'] ) : ?>
												<div class="slider-fullscreen4__slide-headline"></div>
											<?php endif; ?>
											<?php if ( $settings['show_categories'] && ! empty( $item['categories'] ) ) : ?>
												<div class="slider__wrapper-categories">
													<ul class="post-meta">
														<?php foreach ( $item['categories'] as $category ) : ?>
															<li><?php echo esc_html( $category->name ); ?></li>
														<?php endforeach; ?>
													</ul>
												</div>
											<?php endif; ?>
											<h2><?php echo $item['title']; ?></h2>
											<?php if ( $settings['show_description'] && ! empty( $item['description'] ) ) : ?>
												<p><?php echo $item['description']; ?></p>
											<?php endif; ?>
										</header>
									<?php endif; ?>
									<a class="slider-fullscreen4__slide-button button-square" href="<?php echo $item['permalink']; ?>">
										<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
											<g fill="none" fill-rule="evenodd">
												<rect class="rect" width="100%" height="100%"></rect>
											</g>
										</svg>
										<i class="lnr lnr-arrow-right"></i>
									</a>
									<?php
										arr_the_lazy_image(
											array(
												'id'    => $item['image_id'],
												'type'  => 'image',
												'class' => array(
													'wrapper' => false,
													'image'   => array( 'swiper-lazy', 'slider-fullscreen4__slide-bg', 'of-cover' ),
												),
											)
										);
									?>
									<div class="slider-fullscreen4__slide-overlay overlay"></div>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
				<?php if ( $settings['enable_navigation'] || $settings['enable_progress'] || $settings['social'] ) : ?>
					<div class="section-fullscreen__footer container-fluid">
						<div class="row align-items-center justify-content-center">
							<div class="col-lg-4 text-left">
								<?php if ( $settings['enable_navigation'] ) : ?>
									<div class="slider__arrows slider-fullscreen4__arrows">
										<div class="slider__arrow js-slider-fullscreen4-arrow-left eicon-angle-left"></div>
										<div class="slider__arrow js-slider-fullscreen4-arrow-right eicon-angle-right"></div>
									</div>
								<?php endif; ?>
							</div>
							<div class="col-lg-4 text-center">
								<?php if ( $settings['enable_progress'] ) : ?>
									<div class="slider__progress slider-fullscreen4__progress">
										<div class="swiper swiper-container slider__counter slider__counter_current js-slider-fullscreen4-counter-current">
											<div class="swiper-wrapper"></div>
										</div>
										<div class="slider__progressbar js-slider-fullscreen4-progress">
											<div class="slider__progressbar-fill"></div>
										</div>
										<div class="slider__counter slider__counter_total js-slider-fullscreen4-counter-total">00</div>
									</div>
								<?php endif; ?>
							</div>
							<div class="col-lg-4 text-right">
								<?php if ( $settings['social'] ) : ?>
									<div class="slider-fullscreen4__social">
										<ul class="social">
											<?php foreach ( $settings['social'] as $item ) : ?>
												<li class="social__item">
													<?php
														$target   = $item['social_link']['is_external'] ? ' target="_blank"' : '';
														$nofollow = $item['social_link']['nofollow'] ? ' rel="nofollow"' : '';
													?>
													<a class="<?php echo $item['social_icon']; ?>" href="<?php echo $item['social_link']['url']; ?>" <?php echo $target . ' ' . $nofollow; ?>>
														<svg viewBox="0 0 152 152" version="1.1"
															xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
															<g fill="none" fill-rule="evenodd">
																<g transform="translate(-134.000000, -98.000000)">
																	<path class="circle" d="M135,174a75,75 0 1,0 150,0a75,75 0 1,0 -150,0"></path>
																</g>
															</g>
														</svg>
													</a>
												</li>
											<?php endforeach; ?>
										</ul>
									</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php
	}
}
