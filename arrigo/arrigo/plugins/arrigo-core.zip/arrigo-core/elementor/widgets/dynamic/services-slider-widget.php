<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Arrigo_Elementor_Services_Slider_Widget extends \Elementor\Widget_Base {
	private static $_instance = null;

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	public function get_name() {
		return 'arrigo-widget-services-slider';
	}

	public function get_title() {
		return _x( 'Services Slider', 'Elementor Widget Title', 'arrigo' );
	}

	public function get_icon() {
		return 'eicon-sitemap';
	}

	public function get_categories() {
		return array( 'arrigo-dynamic' );
	}

	private $_settings;
	private static $_posts;
	private static $_post_type;

	private static function _get_posts() {

		$args = apply_filters(
			'arr/elementor/arrigo_elementor_services_slider_widget/query_args',
			array(
				'post_type'      => 'arr_services',
				'posts_per_page' => -1,
			)
		);

		$posts   = array();
		$counter = 0;

		$loop = new WP_Query( $args );

		if ( $loop->have_posts() ) {

			while ( $loop->have_posts() ) {

				$loop->the_post();

				$posts[ $counter ]['id']          = get_the_ID();
				$posts[ $counter ]['title']       = get_the_title();
				$posts[ $counter ]['description'] = get_post_meta( $posts[ $counter ]['id'], 'service_short_description', true );
				$posts[ $counter ]['permalink']   = get_the_permalink();
				$counter++;

			}

			wp_reset_postdata();

		}

		self::$_posts     = $posts;
		self::$_post_type = array_key_exists( 'post_type', $args ) ? $args['post_type'] : '';
	}

	protected function register_controls() {

		if ( is_null( self::$_posts ) ) {
			self::_get_posts();
		}

		$posts     = self::$_posts;
		$post_type = self::$_post_type;

		/**
		 * Section Content
		 */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => _x( 'Content', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		foreach ( $posts as $index => $item ) {

			/**
			 * Heading
			 */
			$id = 'heading' . $item['id'];
			$this->add_control(
				$id,
				array(
					'raw'        => sprintf(
						'<h3 class="elementor-control-title"><strong>%1$s</strong>&nbsp;&nbsp;<a href="%2$s" target="_blank"><i class="eicon-edit"></i></a></h3>',
						$item['title'],
						admin_url( 'post.php?post=' . $item['id'] . '&action=edit' ),
						esc_html__( 'Edit', 'arrigo' )
					),
					'type'       => \Elementor\Controls_Manager::RAW_HTML,
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => _x( 'Enabled', 'Elementor Widget', 'arrigo' ),
					'type'       => \Elementor\Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Icon
			 */
			$id = 'icon' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => _x( 'Icon', 'Elementor Widget', 'arrigo' ),
					'type'       => \Elementor\Controls_Manager::ICON,
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Counter Value
			 */
			$id = 'counter' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => _x( 'Counter', 'Elementor Widget', 'arrigo' ),
					'type'       => \Elementor\Controls_Manager::TEXT,
					'separator'  => 'after',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

		}

		$this->add_control(
			'enable_links',
			array(
				'label'   => _x( 'Enable Links to Posts', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		/**
		 * Not Editable Widget Info
		 */
		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s<br><br>%2$s <a href="%3$s" target="_blank">%4$s</a>',
					_x( 'This widget displays content dynamically from the existing posts. It\'s not editable directly through Elementor Page Builder.', 'Elementor Widget', 'arrigo' ),
					_x( 'You can edit or re-order your posts', 'Elementor Widget', 'arrigo' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					_x( 'in WordPress admin panel', 'Elementor Widget', 'arrigo' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Settings
		 */
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => _x( 'Settings', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
			)
		);

		/**
		 * Number of Posts
		 */
		$this->add_control(
			'posts_amount',
			array(
				'label'   => _x( 'Number of Portfolio Items to Display (0 for all)', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'number' => array(
						'min'  => 0,
						'max'  => 16,
						'step' => 1,
					),
				),
				'default' => array(
					'unit' => 'number',
					'size' => 0,
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Section Slider
		 */
		$this->start_controls_section(
			'slider_section',
			array(
				'label' => _x( 'Slider', 'Elementor Widget', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
			)
		);

		/**
		 * Slides Per Screen
		 */
		$this->add_responsive_control(
			'slides_per_view',
			array(
				'label'           => _x( 'Slides Per Screen', 'Elementor Widget', 'arrigo' ),
				'type'            => \Elementor\Controls_Manager::SLIDER,
				'range'           => array(
					'number' => array(
						'min'  => 1,
						'max'  => 4,
						'step' => 1,
					),
				),
				'devices'         => array( 'desktop', 'tablet', 'mobile' ),
				'desktop_default' => array(
					'size' => 4,
					'unit' => 'number',
				),
				'tablet_default'  => array(
					'size' => 2,
					'unit' => 'number',
				),
				'mobile_default'  => array(
					'size' => 1,
					'unit' => 'number',
				),
			)
		);

		/**
		 * Centered Slides
		 */
		$this->add_responsive_control(
			'centered_slides',
			array(
				'label'       => _x( 'Centered Slides', 'Elementor Widget', 'arrigo' ),
				'label_block' => true,
				'type'        => \Elementor\Controls_Manager::SWITCHER,
			)
		);

		/**
		 * Space Between Slides
		 */
		$this->add_responsive_control(
			'space_between',
			array(
				'label'           => _x( 'Space Between Slides', 'Elementor Widget', 'arrigo' ),
				'type'            => \Elementor\Controls_Manager::SLIDER,
				'range'           => array(
					'px' => array(
						'min'  => 0,
						'max'  => 160,
						'step' => 1,
					),
				),
				'devices'         => array( 'desktop', 'tablet', 'mobile' ),
				'desktop_default' => array(
					'size' => 0,
					'unit' => 'px',
				),
				'tablet_default'  => array(
					'size' => 0,
					'unit' => 'px',
				),
				'mobile_default'  => array(
					'size' => 0,
					'unit' => 'px',
				),
			)
		);

		/**
		 * Navigation
		 */
		$this->add_control(
			'enable_navigation',
			array(
				'label'   => _x( 'Enable Navigation Arrows', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		/**
		 * Progress Bar
		 */
		$this->add_control(
			'enable_progress',
			array(
				'label'   => _x( 'Enable Progress Bar', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		/**
		 * Autoplay
		 */
		$this->add_control(
			'enable_autoplay',
			array(
				'label'   => _x( 'Autoplay', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		/**
		 * Autoplay Delay
		 */
		$this->add_control(
			'autoplay_delay',
			array(
				'label'     => _x( 'Autoplay Delay (ms)', 'Elementor Widget', 'arrigo' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'ms' => array(
						'min'  => 1000,
						'max'  => 60000,
						'step' => 100,
					),
				),
				'default'   => array(
					'unit' => 'ms',
					'size' => 6000,
				),
				'condition' => array(
					'enable_autoplay' => 'yes',
				),
			)
		);

		/**
		 * Speed
		 */
		$this->add_control(
			'speed',
			array(
				'label'   => _x( 'Speed', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'ms' => array(
						'min'  => 100,
						'max'  => 10000,
						'step' => 100,
					),
				),
				'default' => array(
					'unit' => 'ms',
					'size' => 800,
				),
			)
		);

		/**
		 * Direction
		 */
		$this->add_control(
			'direction',
			array(
				'label'   => _x( 'Direction', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'default' => 'ltr',
				'options' => array(
					'ltr' => array(
						'title' => _x( 'Left to Right', 'Elementor Widget', 'arrigo' ),
						'icon'  => 'eicon-chevron-double-right',
					),
					'rtl' => array(
						'title' => _x( 'Right to Left', 'Elementor Widget', 'arrigo' ),
						'icon'  => 'eicon-chevron-double-left',
					),
				),
				'toggle'  => false,
			)
		);

		$this->end_controls_section();

		/**
		 * Section Animation
		 */
		$this->start_controls_section(
			'animation_section',
			array(
				'label' => _x( 'Animation', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * OS Animation
		 */
		$this->add_control(
			'enable_animation',
			array(
				'label'        => _x( 'Enable on-scroll animation', 'Elementor Widget', 'arrigo' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'data-os-animation="data-os-animation"',
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings        = $this->get_settings_for_display();
		$this->_settings = $settings;

		if ( is_null( self::$_posts ) ) {
			self::_get_posts();
		}

		$posts = self::$_posts;

		// limit posts amount
		if ( is_array( $settings['posts_amount'] ) && $settings['posts_amount']['size'] > 0 ) {
			array_splice( $posts, $settings['posts_amount']['size'] );
		}

		// filter only "enabled" posts
		$posts = array_filter(
			$posts,
			function( $item ) {
				return ( array_key_exists( 'enabled' . $item['id'], $this->_settings ) ) && ( $this->_settings[ 'enabled' . $item['id'] ] );
			}
		);

		$classRow   = 'justify-content-between';
		$tagService = 'div';

		if ( ( $settings['enable_navigation'] && ! $settings['enable_progress'] ) || ( ! $settings['enable_navigation'] && $settings['enable_progress'] ) ) {
			$classRow = 'justify-content-center';
		}

		$this->add_render_attribute(
			'swiper',
			array(
				'class'                       => array( 'swiper', 'swiper-container', 'slider', 'slider-services', 'js-slider-services' ),
				'data-speed'                  => is_array( $settings['speed'] ) ? $settings['speed']['size'] : 0,
				'dir'                         => $settings['direction'],
				'data-slides-per-view'        => is_array( $settings['slides_per_view'] ) ? $settings['slides_per_view']['size'] : 0,
				'data-slides-per-view-tablet' => is_array( $settings['slides_per_view_tablet'] ) ? $settings['slides_per_view_tablet']['size'] : 0,
				'data-slides-per-view-mobile' => is_array( $settings['slides_per_view_mobile'] ) ? $settings['slides_per_view_mobile']['size'] : 0,
				'data-space-between'          => is_array( $settings['space_between'] ) ? $settings['space_between']['size'] : 0,
				'data-space-between-tablet'   => is_array( $settings['space_between_tablet'] ) ? $settings['space_between_tablet']['size'] : 0,
				'data-space-between-mobile'   => is_array( $settings['space_between_mobile'] ) ? $settings['space_between_mobile']['size'] : 0,
				'data-centered-slides'        => $settings['centered_slides'],
				'data-centered-slides-tablet' => $settings['centered_slides_tablet'],
				'data-centered-slides-mobile' => $settings['centered_slides_mobile'],
			)
		);

		if ( $settings['enable_autoplay'] ) {
			$this->add_render_attribute(
				'swiper',
				array(
					'data-autoplay-enabled' => 'true',
					'data-autoplay-delay'   => is_array( $settings['autoplay_delay'] ) ? $settings['autoplay_delay']['size'] : 0,
				)
			);
		}

		if ( $settings['enable_animation'] ) {
			$this->add_render_attribute( 'swiper', 'data-os-animation' );
		}

		if ( $settings['enable_links'] ) {
			$tagService = 'a';
		}

		?>

		<?php if ( ! empty( $posts ) ) : ?>
			<div <?php echo $this->get_render_attribute_string( 'swiper' ); ?>>
				<div class="swiper-wrapper">
					<?php foreach ( $posts as $item ) : ?>
						<?php
							$post_id = $item['id'];
							$icon    = $settings[ 'icon' . $post_id ];
							$counter = $settings[ 'counter' . $post_id ];

							$this->add_render_attribute(
								'linkAtts',
								array(
									'class' => 'figure-service',
								),
								true,
								true
							);

						if ( $settings['enable_links'] ) {
							$this->add_render_attribute(
								'linkAtts',
								array(
									'class' => 'figure-service',
									'href'  => $item['permalink'],
								),
								true,
								true
							);
						}
						?>
							<div class="swiper-slide slider-services__slide">
								<<?php echo $tagService; ?> <?php echo $this->get_render_attribute_string( 'linkAtts' ); ?>>
									<header class="figure-service__header">
										<div class="figure-service__headline"></div>
										<?php if ( ! empty( $item['title'] ) ) : ?>
											<h3><?php echo $item['title']; ?></h3>
										<?php endif; ?>
										<?php if ( ! empty( $item['description'] ) ) : ?>
											<p><?php echo $item['description']; ?></p>
										<?php endif; ?>
									</header>
									<?php if ( ! empty( $icon ) ) : ?>
										<div class="figure-service__icon">
											<div class="figure-service__icon-symbol <?php echo $icon; ?>"></div>
											<svg viewBox="0 0 152 152" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
												<g fill="none" fill-rule="evenodd">
													<g transform="translate(-134.000000, -98.000000)">
														<path class="circle" d="M135,174a75,75 0 1,0 150,0a75,75 0 1,0 -150,0"></path>
													</g>
												</g>
											</svg>
										</div>
									<?php endif; ?>
									<?php if ( ! empty( $counter ) ) : ?>
										<div class="figure-service__number"><?php echo $counter; ?></div>
									<?php endif; ?>
								</<?php echo $tagService; ?>>
							</div>
						<?php endforeach; ?>
				</div>
				<?php if ( $settings['enable_navigation'] || $settings['enable_progress'] ) : ?>
					<div class="container">
						<div class="row align-items-center <?php echo $classRow; ?>">
							<?php if ( $settings['enable_navigation'] ) : ?>
								<!-- naivgation -->
								<div class="col-auto">
									<div class="slider__arrows slider-services__arrows">
										<div class="slider__arrow js-slider-services__arrow-left eicon-angle-left"></div>
										<div class="slider__arrow js-slider-services__arrow-right eicon-angle-right"></div>
									</div>
								</div>
								<!-- - naivgation -->
							<?php endif; ?>
							<?php if ( $settings['enable_progress'] ) : ?>
								<!-- progress bar -->
								<div class="col-auto">
									<div class="slider__progress">
										<div class="swiper swiper-container slider__counter slider__counter_current js-slider-services-counter-current">
											<div class="swiper-wrapper"></div>
										</div>
										<div class="slider__progressbar js-slider-services-progress">
											<div class="slider__progressbar-fill"></div>
										</div>
										<div class="slider__counter slider__counter_total js-slider-services-counter-total">00</div>
									</div>
								</div>
								<!-- - progress bar -->
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php
	}
}
