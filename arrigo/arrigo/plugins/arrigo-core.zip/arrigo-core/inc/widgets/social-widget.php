<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Widget Social
 */
class Arrigo_Widget_Social extends WP_Widget {
	function __construct() {
		parent::__construct(
			'arrigo_social',
			__( 'Arrigo: Social Media', 'arrigo' ),
			array( 'description' => __( 'Displays social media links', 'arrigo' ) )
		);

		$this->socials = array(
			'facebook'    => array(
				'title' => __( 'Facebook URL', 'arrigo' ),
				'icon'  => 'fa fab fa-facebook fa-fw',
			),
			'twitter'     => array(
				'title' => __( 'Twitter URL', 'arrigo' ),
				'icon'  => 'fa fab fa-twitter fa-fw',
			),
			'instagram'   => array(
				'title' => __( 'Instagram URL', 'arrigo' ),
				'icon'  => 'fa fab fa-instagram fa-fw',
			),
			'linkedin'    => array(
				'title' => __( 'LinkedIn URL', 'arrigo' ),
				'icon'  => 'fa fab fa-linkedin fa-fw',
			),
			'google_plus' => array(
				'title' => __( 'Google Plus URL', 'arrigo' ),
				'icon'  => 'fa fab fa-google-plus fa-fw',
			),
			'vk'          => array(
				'title' => __( 'VK URL', 'arrigo' ),
				'icon'  => 'fa fab fa-vk fa-fw',
			),
			'youtube'     => array(
				'title' => __( 'YouTube URL', 'arrigo' ),
				'icon'  => 'fa fab fa-youtube fa-fw',
			),
			'vimeo'       => array(
				'title' => __( 'Vimeo URL', 'arrigo' ),
				'icon'  => 'fa fab fa-vimeo fa-fw',
			),
			'dribbble'    => array(
				'title' => __( 'Dribbble URL', 'arrigo' ),
				'icon'  => 'fa fab fa-dribbble fa-fw',
			),
			'pinterest'   => array(
				'title' => __( 'Pinterest URL', 'arrigo' ),
				'icon'  => 'fa fab fa-pinterest fa-fw',
			),
			'behance'     => array(
				'title' => __( 'Behance URL', 'arrigo' ),
				'icon'  => 'fa fab fa-behance fa-fw',
			),
			'flickr'      => array(
				'title' => __( 'Flickr URL', 'arrigo' ),
				'icon'  => 'fa fab fa-flickr fa-fw',
			),
			'tumblr'      => array(
				'title' => __( 'Tumblr URL', 'arrigo' ),
				'icon'  => 'fa fab fa-tumblr fa-fw',
			),
			'vine'        => array(
				'title' => __( 'Vine URL', 'arrigo' ),
				'icon'  => 'fa fab fa-vine fa-fw',
			),
			'github'      => array(
				'title' => __( 'Github URL', 'arrigo' ),
				'icon'  => 'fa fab fa-github fa-fw',
			),
			'soundcloud'  => array(
				'title' => __( 'SoundCloud URL', 'arrigo' ),
				'icon'  => 'fa fab fa-soundcloud fa-fw',
			),
		);
	}

	/**
	 * Social Medias
	 *
	 * @var array
	 */
	private $socials;

	/**
	 * Display widget on frontend
	 *
	 * @param array $args     widget arguments.
	 * @param array $instance saved data from settings
	 */
	function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		$widget_id = $args['widget_id'];

		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : '';
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		echo $args['before_widget'];
		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		?>
			<ul class="social">
				<?php foreach ( $this->socials as $index => $item ) : ?>
					<?php $option = @ $instance[ $index ] ? : ''; ?>
					<?php if ( ! empty( $option ) ) : ?>
						<li class="social__item">
							<a class="<?php echo esc_attr( $item['icon'] ); ?>" href="<?php echo esc_url( $option ); ?>" target="_blank">
								<svg viewBox="0 0 152 152" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
									<g fill="none" fill-rule="evenodd">
										<g transform="translate(-134.000000, -98.000000)">
											<path class="circle" d="M135,174a75,75 0 1,0 150,0a75,75 0 1,0 -150,0"></path>
										</g>
									</g>
								</svg>
							</a>
						</li>
					<?php endif; ?>
				<?php endforeach; ?>
			</ul>
		<?php
		echo $args['after_widget'];
	}

	/**
	 * Admin settings
	 *
	 * @param array $instance saved data from settings
	 */
	function form( $instance ) {
		$title = @ $instance['title'] ? : '';

		?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'arrigo' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<br>
		<?php foreach ( $this->socials as $index => $item ) : ?>
			<?php
					$field_name  = $this->get_field_name( $index );
					$field_value = @ $instance[ $index ] ? : '';
					$field_id    = $this->get_field_id( $index );
					$field_title = $item['title'];
			?>
				<p>
					<label for="<?php echo esc_html( $field_id ); ?>"><?php echo esc_html( $item['title'] ); ?></label> 
					<input class="widefat" id="<?php echo esc_html( $field_id ); ?>" name="<?php echo esc_html( $field_name ); ?>" type="text" value="<?php echo esc_url( $field_value ); ?>">
				</p>
		<?php endforeach; ?>

		<?php
	}

	/**
	 * Sanitize and save widget settings.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance new settings
	 * @param array $old_instance previous settings
	 *
	 * @return array data to save
	 */
	function update( $new_instance, $old_instance ) {

		$instance          = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		foreach ( $this->socials as $index => $item ) {

			$url                = $new_instance[ $index ];
			$instance[ $index ] = '';

			if ( ! empty( $url ) ) {
				$instance[ $index ] = esc_url( $url );
			}
		}

		return $instance;
	}
}
