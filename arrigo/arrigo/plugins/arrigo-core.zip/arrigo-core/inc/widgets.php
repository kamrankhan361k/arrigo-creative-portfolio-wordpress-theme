<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'widgets_init', 'arr_register_widgets' );
function arr_register_widgets() {
	$widgets = array(
		'logo'      => 'Arrigo_Widget_Logo',
		'social'    => 'Arrigo_Widget_Social',
		'copyright' => 'Arrigo_Widget_Copyright',
	);

	foreach ( $widgets as $index => $value ) {
		require_once __DIR__ . '/widgets/' . sanitize_key( $index ) . '-widget.php';
		register_widget( $value );
	}
}
