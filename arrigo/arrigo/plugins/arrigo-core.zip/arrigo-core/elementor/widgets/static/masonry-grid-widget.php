<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Arrigo_Elementor_Masonry_Grid_Widget extends \Elementor\Widget_Base {
	private static $_instance = null;

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	public function get_name() {
		return 'arrigo-widget-masonry-grid';
	}

	public function get_title() {
		return _x( 'Masonry Grid & Gallery', 'Elementor Widget Title', 'arrigo' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'arrigo-static' );
	}

	protected function register_controls() {

		/**
		 * Section Content
		 */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => _x( 'Images', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		/**
		 * Gallery Lightbox
		 */
		$this->add_control(
			'gallery',
			array(
				'type'    => \Elementor\Controls_Manager::GALLERY,
				'default' => array(),
			)
		);

		$this->end_controls_section();

		/**
		 * Section Settings
		 */
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => _x( 'Settings', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
			)
		);

		/**
		 * Enable Lightbox
		 */
		$this->add_control(
			'lightbox',
			array(
				'label'   => _x( 'Enable Lightbox', 'Elementor Widget', 'arrigo' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Layout
		 */
		$this->start_controls_section(
			'layout_section',
			array(
				'label' => _x( 'Layout', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_LAYOUT,
			)
		);

		/**
		 * Columns
		 */
		$this->add_responsive_control(
			'columns',
			array(
				'label'           => _x( 'Columns', 'Elementor Widget', 'arrigo' ),
				'type'            => \Elementor\Controls_Manager::SELECT,
				'options'         => array(
					3  => _x( 'Four Columns', 'Elementor Widget', 'arrigo' ),
					4  => _x( 'Three Columns', 'Elementor Widget', 'arrigo' ),
					6  => _x( 'Two Columns', 'Elementor Widget', 'arrigo' ),
					12 => _x( 'Single Column', 'Elementor Widget', 'arrigo' ),
				),
				'render_type'     => 'template',
				'desktop_default' => 4,
				'tablet_default'  => 6,
				'mobile_default'  => 12,
			)
		);

		/**
		 * Space Between
		 */
		$this->add_responsive_control(
			'space_between',
			array(
				'label'           => _x( 'Space Between', 'Elementor Widget', 'arrigo' ),
				'type'            => \Elementor\Controls_Manager::SLIDER,
				'range'           => array(
					'px' => array(
						'min'  => 0,
						'max'  => 120,
						'step' => 1,
					),
				),
				'devices'         => array( 'desktop', 'tablet', 'mobile' ),
				'desktop_default' => array(
					'size' => 80,
				),
				'tablet_default'  => array(
					'size' => 30,
				),
				'mobile_default'  => array(
					'size' => 15,
				),
				'selectors'       => array(
					'{{WRAPPER}} .grid'       => 'margin: calc(-{{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid__item' => 'padding: calc({{SIZE}}{{UNIT}} / 2);',
				),
				'render_type'     => 'template',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Animation
		 */
		$this->start_controls_section(
			'animation_section',
			array(
				'label' => _x( 'Animation', 'Elementor Widget Section', 'arrigo' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * OS Animation
		 */
		$this->add_control(
			'enable_animation',
			array(
				'label'        => _x( 'Enable on-scroll animation', 'Elementor Widget', 'arrigo' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'data-os-animation="data-os-animation"',
			)
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings    = $this->get_settings_for_display();
		$col_desktop = 'grid__item_desktop-' . $settings['columns'];
		$col_tablet  = 'grid__item_tablet-' . $settings['columns_tablet'];
		$col_mobile  = 'grid__item_mobile-' . $settings['columns_mobile'];
		$lightbox    = $settings['lightbox'];

		$this->add_render_attribute(
			'section',
			array(
				'class'                    => array( 'grid', 'js-grid' ),
				'data-grid-columns'        => 12 / $settings['columns'],
				'data-grid-columns-tablet' => 12 / $settings['columns_tablet'],
				'data-grid-columns-mobile' => 12 / $settings['columns_mobile'],
			)
		);

		$this->add_render_attribute(
			'itemAtts',
			array(
				'class' => array( 'grid__item', 'js-grid__item', $col_desktop, $col_tablet, $col_mobile ),
			)
		);

		$this->add_render_attribute(
			'sizerAtts',
			array(
				'class' => array( 'grid__sizer', 'js-grid__sizer', $col_desktop, $col_tablet, $col_mobile ),
			)
		);

		if ( $settings['enable_animation'] ) {
			$this->add_render_attribute( 'section', 'data-os-animation' );
		}

		?>

		<?php if ( ! empty( $settings['gallery'] ) ) : ?>
			<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
				<div <?php echo $this->get_render_attribute_string( 'sizerAtts' ); ?>></div>
				<?php foreach ( $settings['gallery'] as $image ) : ?>
					<div <?php echo $this->get_render_attribute_string( 'itemAtts' ); ?>>
						<?php
						if ( $lightbox ) {
							$this->add_render_attribute(
								'lightboxAtts',
								array(
									'class' => 'grid__item-link',
									'href'  => $image['url'],
									'data-elementor-open-lightbox' => 'true',
									'data-elementor-lightbox-slideshow' => $this->get_id(),
								),
								true,
								true
							);
							?>
						<a <?php echo $this->get_render_attribute_string( 'lightboxAtts' ); ?>>
							<div class="grid__item-icon">
								<div class="grid__item-icon-symbol lnr lnr-magnifier"></div>
								<svg viewBox="0 0 152 152" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
									<g fill="none" fill-rule="evenodd">
										<g transform="translate(-134.000000, -98.000000)">
											<path class="circle" d="M135,174a75,75 0 1,0 150,0a75,75 0 1,0 -150,0"></path>
										</g>
									</g>
								</svg>
							</div>
							<div class="overlay overlay_dark grid__item-overlay"></div>
						<?php } ?>
							<?php
								arr_the_lazy_image(
									array(
										'id'    => $image['id'],
										'class' => array(
											'wrapper' => array( 'position-relative' ),
											'image'   => array(),
										),
									)
								);
							?>
						<?php if ( $lightbox ) : ?>
						</a>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<?php
	}

	protected function content_template() {
		?>
		<#
			var col_desktop = 'grid__item_desktop-' + settings.columns;
			var col_tablet  = 'grid__item_tablet-' + settings.columns_tablet;
			var col_mobile  = 'grid__item_mobile-' + settings.columns_mobile;
			var lightbox = settings.lightbox;

			view.addRenderAttribute(
				'itemAtts', {
					'class': ['grid__item', 'js-grid__item', col_desktop, col_tablet, col_mobile],
				}
			);

			view.addRenderAttribute(
				'sizerAtts', {
					'class': ['grid__sizer', 'js-grid__sizer', col_desktop, col_tablet, col_mobile],
				}
			);
		#>

		<# if (settings.gallery.length) { #>
			<div class="grid js-grid js-gallery">
				<div {{{ view.getRenderAttributeString('sizerAtts') }}}></div>
				<# _.each( settings.gallery, function( image ) { #>
					<div {{{ view.getRenderAttributeString('itemAtts') }}}>
						<#
							if (lightbox) {
								view.addRenderAttribute(
								'lightboxAtts', {
									'class': 'grid__item-link',
									'href': image.url,
									'data-elementor-open-lightbox': 'true',
									'data-elementor-lightbox-slideshow': id,
								}, true, true
							);
						#>
							<a {{{ view.getRenderAttributeString('lightboxAtts') }}}>
								<div class="grid__item-icon">
									<div class="grid__item-icon-symbol lnr lnr-magnifier"></div>
									<svg viewBox="0 0 152 152" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
										<g fill="none" fill-rule="evenodd">
											<g transform="translate(-134.000000, -98.000000)">
												<path class="circle" d="M135,174a75,75 0 1,0 150,0a75,75 0 1,0 -150,0"></path>
											</g>
										</g>
									</svg>
								</div>
								<div class="overlay overlay_dark grid__item-overlay"></div>
						<# } #>
							<img src="{{{ image.url }}}" alt=""/>
						<# if (lightbox) { #>
							</a>
						<# } #>
					</div>
				<# }); #>
			</div>
		<# } #>

		<?php
	}
}
